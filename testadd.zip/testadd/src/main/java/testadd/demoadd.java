package testadd;

public class demoadd {
	public int Add(String numbers) {
		return 0;
	}

}
